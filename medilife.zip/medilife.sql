-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2019 at 07:42 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medilife`
--

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`id`, `name`, `email`, `password`, `role`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', 'admin', '0', '1', '', NULL, NULL),
(2, 'Pharmacy', 'pharmacy@gmail.com', '123', '3', '1', '', NULL, NULL),
(3, 'Athira', 'athira@gmail.com', 'athira', '2', '1', '', NULL, NULL),
(4, 'mmmm', 'ab@gmail.com', 'mmmm', '2', '1', '', NULL, NULL),
(5, 'aaaas', 'q@gmail.com', 'mmm', '2', '1', '', NULL, NULL),
(6, 'nnnn', 'amn@gmail.com', 'hhhh', '2', '1', '', NULL, NULL),
(7, 'ssss', 'jintumolthomas@mca.ajce.in', '$2y$10$yVMDIr1yJIsPOhShOh2e0O8Cu49g0e6753x7b6akXiNaJZ58oySwi', '1', '1', '8Nn2c4Lsu57dq35P883WUxYMXmrKhMEhuIcwPAcu1CRVWoGQLLaxPQ0Rz2an', NULL, '2019-03-17 17:15:56'),
(8, 'Besty', 'besty@gmail.com', 'Besty123', '1', '1', 'null', NULL, NULL),
(9, 'Varsha', 'varsha@gmail.com', 'mjiii', '2', '1', 'null', NULL, NULL),
(10, 'nnnn', 'ass@gmail.com', 'hhhh', '2', '1', 'null', NULL, NULL),
(11, 'mariii', 'amnb@gmail.com', 'qwerty', '2', '1', 'null', NULL, NULL),
(12, 'mariya', 'mariya@gmail.com', 'mariya', '2', '1', 'null', NULL, NULL),
(13, 'meenu', 'meenu@gmail.com', 'Meenu1996@', '2', '1', 'null', NULL, NULL),
(14, 'Tina', 'tinajose1996@gmail.com', 'tina1996@', '2', '1', 'null', NULL, NULL),
(15, 'aqwwerty', 'abbb@gmail.com', 'Abc12345', '1', '1', 'null', NULL, NULL),
(16, 'Sobia', 'sobia@gmail.com', 'qwertyui', '2', '1', 'null', NULL, NULL),
(18, 'ANNA', 'anna@gmail.com', 'Anna0118', '2', '1', 'null', NULL, NULL),
(19, 'ambili', 'ambili@gmail.com', 'Ambili@123', '2', '1', 'null', NULL, NULL),
(20, 'aaaaa', 'meenu@gmail.com', 'Abc12345', '1', '1', 'null', NULL, NULL),
(21, 'naya', 'navya@gmail.com', 'Abc12345', '1', '1', 'null', NULL, NULL),
(22, 'lal', 'lal@gmail.com', 'lal', '2', '1', 'null', NULL, NULL),
(23, 'xcvbnm', 'aswq@gmail.com', 'qwert', '2', '1', 'null', NULL, NULL),
(24, 'avilash', 'avi@gmail.com', 'avi', '2', '1', 'null', NULL, NULL),
(25, 'Arun', 'arunthomas@mca.ajce.in', 'Arunth1', '1', '1', 'null', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_03_05_223208_create_logins_table', 1),
(2, '2019_03_06_042135_create_registers_table', 2),
(3, '2019_03_10_154243_create_tbl__doctors_table', 3),
(4, '2019_03_15_164451_create_registers_table', 4),
(5, '2019_03_15_164824_create_logins_table', 5),
(6, '2019_03_15_165202_create_tbl_district_table', 6),
(7, '2019_03_15_165334_create_tbl_city_table', 7),
(8, '2019_03_17_174327_create_specilizations_table', 8),
(9, '2019_03_17_222507_password_resets', 9),
(10, '2019_03_17_223311_password_resets', 10),
(11, '2019_03_27_041500_create_tbl_pharmacies_table', 11),
(12, '2019_03_27_155154_create_tbl_brands_table', 12),
(13, '2019_03_27_160008_create_tbl_categories_table', 13),
(14, '2019_03_27_215648_tbl_request', 14),
(15, '2019_03_30_033418_tbl_date', 15),
(16, '2019_03_30_034257_create_tbl_leaves_table', 16),
(17, '2019_03_30_045652_create_dates_table', 16),
(18, '2019_04_02_032759_create_tbl_images_table', 17),
(19, '2019_04_09_052853_create_tblcarts_table', 18),
(20, '2019_04_10_181242_create_tblcarts_table', 19),
(21, '2019_04_23_205802_create_tbl_doctor_histories_table', 20),
(22, '2019_04_23_212323_create_tbl_doctor_histories_table', 21),
(23, '2019_04_24_032705_create_tbl_appoinments_table', 22),
(24, '2019_04_28_155140_create_tbl_medicine_requests_table', 23),
(25, '2019_04_28_160109_create_tbl_medicine_requests_table', 24),
(26, '2019_04_28_160813_create_tbl_prescriptions_table', 25),
(27, '2019_04_29_154534_create_tbl_cards_table', 26),
(28, '2019_04_29_155336_create_tbl_banks_table', 27),
(29, '2019_05_01_210351_create_tbl_requires_table', 28),
(30, '2019_05_06_191034_create_tbl_orders_table', 29),
(31, '2019_05_08_041241_create_tbl__delievry_addresses_table', 29),
(32, '2019_05_08_212518_create_tbl__amounts_table', 30),
(33, '2019_05_08_214649_create_tbl__orders_table', 31),
(34, '2019_05_12_022802_create_tbl_treatments_table', 32);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registers`
--

CREATE TABLE `registers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `registers`
--

INSERT INTO `registers` (`id`, `p_name`, `email`, `gender`, `dob`, `phone`, `h_name`, `street`, `district`, `city`, `pin`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'sona', 'sona@gmail.com', 'Female', '2019-03-07', '98765433', 'karrrrrr', 'Kappimala', '2', '4', '654432', '1', '1', '2019-03-16 00:36:43', '2019-03-16 00:36:43'),
(2, 'Alice', 'alice@gmail.com', 'Female', '2019-03-07', '9877876543', 'khytreaa', 'kiuytreww', '1', '1', '654434', '1', '1', '2019-03-16 00:44:53', '2019-03-16 00:44:53'),
(3, 'ssss', 'bb@gmail.com', 'Female', '2019-03-22', '986555', 'aa', 'nnnn', '1', '1', '8888', '1', '1', '2019-03-17 11:52:39', '2019-03-17 11:52:39'),
(4, 'Besty', 'besty@gmail.com', 'Female', '2019-03-08', '9877874432', 'ahuhggyfgyggy', 'hhhjjj', '1', '1', '89999999', '1', '1', '2019-03-17 21:09:34', '2019-03-17 21:09:34'),
(5, 'aqwwerty', 'abbb@gmail.com', 'uuyytrr', '2019-03-21', '9207064521', 'kalaketty', 'kalaketty', '2', '2', '686631', '1', '1', '2019-03-18 17:59:26', '2019-03-18 17:59:26'),
(6, 'AnnaThomas', 'anna@gmail.com', 'Female', '2019-03-20', '7510647707', 'xxxx', 'kalaketty', '1', '3', '686631', '1', '1', '2019-03-19 13:02:18', '2019-03-19 13:02:18'),
(7, 'Meenu', 'meenu@gmail.com', 'Female', '1996-03-01', '9207064521', 'kalaketty', 'kalaketty', '1', '1', '686631', '1', '1', '2019-03-19 17:25:33', '2019-03-19 17:25:33'),
(8, 'naya', 'navya@gmail.com', 'Male', '2019-03-21', '9888989909', 'zxcvbnm', 'xcvbnm', '2', '2', '678876', '1', '1', '2019-03-21 12:40:34', '2019-03-21 12:40:34'),
(9, 'Arun', 'arunthomas@mca.ajce.in', 'Male', '1995-01-15', '9544103818', 'Eathakattu', 'Marigiry', '1', '1', '685609', '1', '1', '2019-04-29 17:59:00', '2019-04-29 17:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `specilizations`
--

CREATE TABLE `specilizations` (
  `sid` bigint(20) UNSIGNED NOT NULL,
  `specilization` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `specilizations`
--

INSERT INTO `specilizations` (`sid`, `specilization`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Cadiology', '1', NULL, NULL),
(2, 'Gynacology', '1', NULL, NULL),
(3, 'Radiology', '1', NULL, NULL),
(4, 'xxxx', '1', NULL, NULL),
(5, 'Nerology', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcarts`
--

CREATE TABLE `tblcarts` (
  `cart_id` bigint(20) UNSIGNED NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `mid` bigint(20) UNSIGNED NOT NULL,
  `quantity` bigint(20) UNSIGNED NOT NULL,
  `price` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_appoinments`
--

CREATE TABLE `tbl_appoinments` (
  `a_id` bigint(20) UNSIGNED NOT NULL,
  `d_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_appoinments`
--

INSERT INTO `tbl_appoinments` (`a_id`, `d_id`, `p_id`, `date`, `time`, `status`, `created_at`, `updated_at`) VALUES
(1, '18', '7', '05/18/2019', '10:00-10:30', '1', NULL, NULL),
(2, '18', '7', '04/18/2019', '11:00-11:30', '1', NULL, NULL),
(3, '8', '7', '04/17/2019', '10:00-10:30', '1', NULL, NULL),
(7, '12', '7', '04/03/2019', '09:00-9:30', '1', NULL, NULL),
(13, '9', '7', '04/18/2019', '09:30-10:00', '1', NULL, NULL),
(14, '9', '7', '04/18/2019', '09:30-10:00', '1', NULL, NULL),
(15, '9', '7', '04/18/2019', '09:30-10:00', '1', NULL, NULL),
(31, '9', '7', '05/15/2019', '09:30-10:00', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banks`
--

CREATE TABLE `tbl_banks` (
  `b_id` bigint(20) UNSIGNED NOT NULL,
  `c_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` bigint(191) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_banks`
--

INSERT INTO `tbl_banks` (`b_id`, `c_id`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(1, '1', -2877, '1', NULL, NULL),
(2, '2', 20938, '1', NULL, NULL),
(3, '3', 8639, '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_brands`
--

CREATE TABLE `tbl_brands` (
  `b_id` bigint(20) UNSIGNED NOT NULL,
  `b_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_brands`
--

INSERT INTO `tbl_brands` (`b_id`, `b_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'jyothi Laboratory', '1', NULL, NULL),
(2, 'cccccc', '1', NULL, NULL),
(3, 'Synthroid', '1', NULL, NULL),
(4, 'Timoptic', '1', NULL, NULL),
(5, 'Toprol XL', '1', NULL, NULL),
(6, 'Effexor', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cards`
--

CREATE TABLE `tbl_cards` (
  `c_id` bigint(20) UNSIGNED NOT NULL,
  `c_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cvv` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_cards`
--

INSERT INTO `tbl_cards` (`c_id`, `c_name`, `c_number`, `cvv`, `exp`, `status`, `created_at`, `updated_at`) VALUES
(1, 'MEENU THOMAS', '5678 8980 0432 222', '345', '09 / 2021', '1', NULL, NULL),
(2, 'ANU THOMAS', '4578 8982 341', '876', '09 / 2019', '1', NULL, NULL),
(3, 'ADMIN', '1234567876', '123', '09/2022', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_categories`
--

CREATE TABLE `tbl_categories` (
  `c_id` bigint(20) UNSIGNED NOT NULL,
  `c_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_categories`
--

INSERT INTO `tbl_categories` (`c_id`, `c_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Fever', '1', NULL, NULL),
(2, 'Hallucinogens', '1', NULL, NULL),
(3, 'Stimulants', '1', NULL, NULL),
(4, 'Opioids', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_city`
--

CREATE TABLE `tbl_city` (
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `city_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_city`
--

INSERT INTO `tbl_city` (`city_id`, `district_id`, `city_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Ettumanoor', '2019-03-19 18:30:00', '2019-03-18 18:30:00'),
(2, 2, 'kajagad', '2019-03-17 18:30:00', '2019-03-12 18:30:00'),
(3, 1, 'Kajirapally', '2019-03-13 18:30:00', '2019-03-18 18:30:00'),
(4, 2, 'Bekkal', '2019-03-20 18:30:00', '2019-03-12 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Kottayam', '2019-03-27 18:30:00', '2019-03-24 18:30:00'),
(2, 'Kasargod', '2019-03-24 18:30:00', '2019-03-26 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_doctor_histories`
--

CREATE TABLE `tbl_doctor_histories` (
  `dh_id` bigint(20) UNSIGNED NOT NULL,
  `d_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `history` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_doctor_histories`
--

INSERT INTO `tbl_doctor_histories` (`dh_id`, `d_id`, `history`, `status`, `created_at`, `updated_at`) VALUES
(1, '18', 'aa', '1', '2019-04-23 15:59:08', '2019-04-23 15:59:08'),
(2, '18', 'eee', '1', '2019-04-23 15:59:09', '2019-04-23 15:59:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_images`
--

CREATE TABLE `tbl_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mid` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_images`
--

INSERT INTO `tbl_images` (`id`, `image`, `mid`, `created_at`, `updated_at`) VALUES
(1, 'm3.jpg', 12, '2019-04-01 23:33:28', '2019-04-01 23:33:28'),
(2, 'm1.jpg', 12, '2019-04-01 23:33:28', '2019-04-01 23:33:28'),
(3, 'm2.jpg', 12, '2019-04-01 23:33:28', '2019-04-01 23:33:28'),
(4, 'p1.jpg', 13, '2019-04-10 21:28:15', '2019-04-10 21:28:15'),
(5, 'p2.jpg', 13, '2019-04-10 21:28:15', '2019-04-10 21:28:15'),
(6, 'p3.jpg', 13, '2019-04-10 21:28:15', '2019-04-10 21:28:15'),
(7, 'ss1.jpg', 14, '2019-04-10 21:31:27', '2019-04-10 21:31:27'),
(8, 'ss2.jpg', 14, '2019-04-10 21:31:27', '2019-04-10 21:31:27'),
(9, 'ss3.jpg', 14, '2019-04-10 21:31:27', '2019-04-10 21:31:27'),
(10, '6.jpg', 15, '2019-04-11 10:23:37', '2019-04-11 10:23:37'),
(11, '7.jpg', 15, '2019-04-11 10:23:37', '2019-04-11 10:23:37'),
(12, '8.jpg', 15, '2019-04-11 10:23:37', '2019-04-11 10:23:37'),
(13, '8.jpg', 16, '2019-05-01 22:38:50', '2019-05-01 22:38:50'),
(14, '9.jpg', 16, '2019-05-01 22:38:50', '2019-05-01 22:38:50'),
(15, 'dolo.jpg', 16, '2019-05-01 22:38:50', '2019-05-01 22:38:50'),
(16, 'kit1.jpg', 17, '2019-05-04 00:17:00', '2019-05-04 00:17:00'),
(17, 'kit2.jpg', 17, '2019-05-04 00:17:01', '2019-05-04 00:17:01'),
(18, 'kit3.jpg', 17, '2019-05-04 00:17:01', '2019-05-04 00:17:01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leaves`
--

CREATE TABLE `tbl_leaves` (
  `l_id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_leaves`
--

INSERT INTO `tbl_leaves` (`l_id`, `email`, `date`, `session`, `reason`, `status`, `created_at`, `updated_at`) VALUES
(10, '18', '04/18/2019', 'FN', 'mmm', '1', '2019-04-08 23:19:16', '2019-04-08 23:19:16'),
(11, '18', '04/17/2019', 'FULL DAY', 'oooo', '1', '2019-04-08 23:19:16', '2019-04-08 23:19:16'),
(12, '18', '04/18/2019', 'FN', 'mmmm', '1', '2019-04-08 23:25:19', '2019-04-08 23:25:19'),
(14, '18', '04/18/2019', 'FN', 'rrree', '0', '2019-04-08 23:28:27', '2019-04-08 23:28:27'),
(15, '18', '04/17/2019', 'FN', 'bbbb', '0', '2019-04-08 23:28:27', '2019-04-08 23:28:27'),
(16, '18', '04/18/2019', 'FN', 'qqqqqq', '0', '2019-04-08 23:34:06', '2019-04-08 23:34:06'),
(17, '18', '04/17/2019', 'FN', 'eeeee', '2', '2019-04-08 23:34:07', '2019-04-08 23:34:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_medicine_requests`
--

CREATE TABLE `tbl_medicine_requests` (
  `mr_id` bigint(20) UNSIGNED NOT NULL,
  `r_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_medicine_requests`
--

INSERT INTO `tbl_medicine_requests` (`mr_id`, `r_id`, `mid`, `status`, `created_at`, `updated_at`) VALUES
(20, '1', '14', '1', '2019-05-05 22:58:23', '2019-05-01 16:57:31'),
(21, '1', '12', '1', '2019-05-05 21:20:24', '2019-05-01 16:57:31'),
(22, '2', '12', '1', '2019-05-03 04:31:04', '2019-05-01 17:13:44'),
(23, '2', '13', '0', '2019-05-03 03:41:47', '2019-05-01 17:13:44'),
(24, '4', '15', '2', '2019-05-06 16:20:05', '2019-05-06 10:48:02'),
(25, '4', '16', '1', '2019-05-06 10:48:02', '2019-05-06 10:48:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pharmacies`
--

CREATE TABLE `tbl_pharmacies` (
  `mid` bigint(20) UNSIGNED NOT NULL,
  `b_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `m_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gram` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_pharmacies`
--

INSERT INTO `tbl_pharmacies` (`mid`, `b_id`, `c_id`, `m_name`, `gram`, `quantity`, `price`, `description`, `type`, `status`, `created_at`, `updated_at`) VALUES
(12, '1', '1', 'Magneto', '12', '1', '22', 'This drug is used to treat mild to moderate pain (from headaches, menstrual periods, toothaches, backaches, osteoarthritis, or cold/flu aches and pains) and to reduce fever.', 'p_not', '1', '2019-04-01 23:33:27', '2019-04-01 23:33:27'),
(13, '4', '4', 'Latreopuy', '23', '7', '32', 'A carbocyclic nucleoside with potent selective anti-HIV activity.', 'p_need', '1', '2019-04-10 21:28:14', '2019-04-10 21:28:14'),
(14, '3', '2', 'Acarbose', '12', '32', '15', 'An inhibitor of ALPHA-GLUCOSIDASES that retards the digestion and absorption of DIETARY CARBOHYDRATES in the SMALL INTESTINE.', 'p_not', '1', '2019-04-10 21:31:27', '2019-04-10 21:31:27'),
(15, '4', '4', 'Deotuyt', '4', '12', '25', 'A carbocyclic nucleoside with potent selective anti-HIV activity.', 'p_need', '1', '2019-04-11 10:23:36', '2019-04-11 10:23:36'),
(16, '5', '1', 'Dolo', '650 mg', '20', '29', 'Dolo 650 mg Tablet 151 is commonly used drug to reduce pain and lower high temperatures (fever). It is also used to treat headache, toothache, joint ache and other feverish conditions.', 'p_need', '1', '2019-05-01 22:38:49', '2019-05-01 22:38:49'),
(17, '6', '4', 'Milton Medical Box', '250gm', '10', '147.00', 'Box only, medicines are not included with this box .Compact shape for easy storage .Partition tray for segregation See through lid with handle.', 'p_not', '1', '2019-05-04 00:16:59', '2019-05-04 00:16:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prescriptions`
--

CREATE TABLE `tbl_prescriptions` (
  `pr_id` bigint(20) UNSIGNED NOT NULL,
  `r_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prescription` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_prescriptions`
--

INSERT INTO `tbl_prescriptions` (`pr_id`, `r_id`, `prescription`, `status`) VALUES
(16, '1', 'Doctor Patient Portal.pptx', '1'),
(17, '1', 'FORM DESIGN.docx', '1'),
(18, '2', 'Output.odt', '1'),
(19, '3', 'FORM DESIGN.docx', '1'),
(20, '4', 'FORM DESIGN.docx', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_requests`
--

CREATE TABLE `tbl_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `request` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_requests`
--

INSERT INTO `tbl_requests` (`id`, `request`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Lactogen', '1', NULL, NULL),
(2, 'zzxza', '0', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_requires`
--

CREATE TABLE `tbl_requires` (
  `r_id` bigint(20) UNSIGNED NOT NULL,
  `p_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_requires`
--

INSERT INTO `tbl_requires` (`r_id`, `p_id`, `date`, `status`, `created_at`, `updated_at`) VALUES
(1, '7', '2019-05-01', '1', '2019-05-01 16:57:31', '2019-05-01 16:57:31'),
(2, '8', '2019-05-01', '1', '2019-05-01 17:13:44', '2019-05-01 17:13:44'),
(3, '9', '2019-05-01', '1', '2019-05-01 17:14:09', '2019-05-01 17:14:09'),
(4, '7', '2019-05-06', '1', '2019-05-06 10:48:02', '2019-05-06 10:48:02');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_time`
--

CREATE TABLE `tbl_time` (
  `time_id` int(11) NOT NULL,
  `time` varchar(25) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_time`
--

INSERT INTO `tbl_time` (`time_id`, `time`, `status`) VALUES
(1, '08:00-8:30', 1),
(2, '08:30-9:00', 1),
(3, '09:00-9:30', 1),
(4, '09:30-10:00', 1),
(5, '10:00-10:30', 1),
(6, '10:30-11:00', 1),
(7, '11:00-11:30', 1),
(8, '11:30-12:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_treatments`
--

CREATE TABLE `tbl_treatments` (
  `trt_id` bigint(20) UNSIGNED NOT NULL,
  `p_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `d_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `treatment` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl__amounts`
--

CREATE TABLE `tbl__amounts` (
  `amt_id` bigint(20) UNSIGNED NOT NULL,
  `p_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl__amounts`
--

INSERT INTO `tbl__amounts` (`amt_id`, `p_id`, `amount`, `status`, `created_at`, `updated_at`) VALUES
(14, '7', '72', '1', NULL, NULL),
(15, '7', '72', '1', NULL, NULL),
(16, '7', '72', '1', NULL, NULL),
(17, '7', '72', '1', NULL, NULL),
(18, '7', '72', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl__delievry_addresses`
--

CREATE TABLE `tbl__delievry_addresses` (
  `dl_id` bigint(20) UNSIGNED NOT NULL,
  `p_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl__delievry_addresses`
--

INSERT INTO `tbl__delievry_addresses` (`dl_id`, `p_id`, `name`, `address`, `city`, `district`, `pin`, `phone`, `status`, `created_at`, `updated_at`) VALUES
(41, '7', 'Manu', 'kalaketty,', 'sdfghjkl;', 'Kottayam', '686631', '9207064521', '1', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl__doctors`
--

CREATE TABLE `tbl__doctors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `d_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quali` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `y_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emp_history` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fee` bigint(191) NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl__doctors`
--

INSERT INTO `tbl__doctors` (`id`, `d_name`, `surname`, `dob`, `gender`, `sid`, `h_name`, `city`, `state`, `country`, `zip`, `email`, `phone`, `quali`, `y_exp`, `emp_history`, `fee`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(8, 'nnnn', 'jjjj', '2019-03-20', 'Male', '2', 'bnnnn', 'hhjjj', 'ghhhh', 'hhhh', '678876', 'ass@gmail.com', '9876567897', 'nnnn', '5', 'hhhh', 200, 't3.jpg', '1', '2019-03-17 23:05:52', '2019-03-17 23:05:52'),
(9, 'mariii', 'jjj', '2019-02-28', 'Male', '3', 'nnn', 'jjjj', 'jjjj', 'jjj', '687765', 'amnb@gmail.com', '9877678987', 'jjjj', '9', 'jjj', 677, 't1.jpg', '1', '2019-03-17 23:39:47', '2019-03-17 23:39:47'),
(10, 'mariya', 'Mathew', '2019-03-15', 'Male', '1', 'mnhh', 'hhh', 'hhh', 'hh', '654456', 'mariya@gmail.com', '987654323', 'ggh', '8', 'nnn', 88, '5.jpg', '1', '2019-03-18 00:01:32', '2019-03-18 00:01:32'),
(11, 'meenu', 'uuyytrr', '2019-03-13', 'Male', '2', 'oolaparambil', 'oolambara', 'kuthiravattom', 'india', '686631', 'meenu@gmail.com', '9207064521', 'lkg', '1', 'sdfghjl', 45, '1.jpg', '0', '2019-03-18 13:57:51', '2019-03-18 13:57:51'),
(12, 'Tina', 'Jose', '1996-11-15', 'Female', '1', 'Karippakkudiyil', 'vellilappilly', 'kerala', 'india', '686576', 'tinajose1996@gmail.com', '9207064521', 'MD', '5', 'RIMS,KITS', 50000, 'p1.jpg', '1', '2019-03-18 14:05:47', '2019-03-18 14:05:47'),
(13, 'Sobia', 'Shajihhhjj', '2019-03-20', 'Female', '2', 'sfhk;', 'fghjk', 'fghjk', 'fghjk', '686576', 'sobia@gmail.com', '98765433', 'nnnn', '2', 'caritas', 200, 't2.jpg', '1', '2019-03-19 00:52:19', '2019-03-19 00:52:19'),
(14, 'ANNA', 'THOMAS', '2019-03-20', 'Female', '1', 'xxxx', 'xxxxx', 'xxxxx', 'India', '686631', 'anna@gmail.com', '9207064521', 'MBBS', '3', 'xxxxxxxxxxxxxxx', 4888, 't1.jpg', '0', '2019-03-19 13:07:30', '2019-03-19 13:07:30'),
(15, 'ambili', 'antony', '2019-03-15', 'Female', '1', 'pulickal', 'kannur', 'kerala', 'india', '670582', 'ambili@gmail.com', '7558814170', 'mbbs', '2', 'esrfsdfsd', 100, 't1.jpg', '0', '2019-03-19 13:36:50', '2019-03-19 13:36:50'),
(16, 'lal', 'malhothra', NULL, 'Male', '3', 'qqqqq', 'nnnnn', 'kersk', 'bnm', '899909', 'lal@gmail.com', '9888990098', 'mbbs', NULL, NULL, 100, 't3.jpg', '1', '2019-03-24 22:31:46', '2019-03-24 22:31:46'),
(17, 'xcvbnm', 'wertyu', NULL, 'Female', '5', 'qwwww', 'eeee', 'ddddfff', 'ffffff', '6788898', 'aswq@gmail.com', '9888987656', 'mmb', NULL, NULL, 123, 't2.jpg', '0', '2019-03-24 22:40:55', '2019-03-24 22:40:55'),
(18, 'avilash', 'Mathew', '2019-05-23', 'Male', '3', 'plathottam', 'kajirappally', 'Kerala', 'India', '689963', 'avi@gmail.com', '9888984599', 'mdnn', '3', NULL, 100, 'avatar-1.jpeg', '1', '2019-03-26 21:03:33', '2019-03-26 21:03:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl__orders`
--

CREATE TABLE `tbl__orders` (
  `o_id` bigint(20) UNSIGNED NOT NULL,
  `amt_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl__orders`
--

INSERT INTO `tbl__orders` (`o_id`, `amt_id`, `p_id`, `mid`, `quantity`, `price`, `status`, `created_at`, `updated_at`) VALUES
(3, '14', '7', '12', '1', '22', '1', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registers`
--
ALTER TABLE `registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specilizations`
--
ALTER TABLE `specilizations`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `tblcarts`
--
ALTER TABLE `tblcarts`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `tblcarts_id_foreign` (`id`),
  ADD KEY `tblcarts_mid_foreign` (`mid`);

--
-- Indexes for table `tbl_appoinments`
--
ALTER TABLE `tbl_appoinments`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `tbl_banks`
--
ALTER TABLE `tbl_banks`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `tbl_brands`
--
ALTER TABLE `tbl_brands`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `tbl_cards`
--
ALTER TABLE `tbl_cards`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD PRIMARY KEY (`city_id`),
  ADD KEY `tbl_city_district_id_foreign` (`district_id`);

--
-- Indexes for table `tbl_district`
--
ALTER TABLE `tbl_district`
  ADD PRIMARY KEY (`district_id`);

--
-- Indexes for table `tbl_doctor_histories`
--
ALTER TABLE `tbl_doctor_histories`
  ADD PRIMARY KEY (`dh_id`);

--
-- Indexes for table `tbl_images`
--
ALTER TABLE `tbl_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_images_mid_foreign` (`mid`);

--
-- Indexes for table `tbl_leaves`
--
ALTER TABLE `tbl_leaves`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `tbl_medicine_requests`
--
ALTER TABLE `tbl_medicine_requests`
  ADD PRIMARY KEY (`mr_id`);

--
-- Indexes for table `tbl_pharmacies`
--
ALTER TABLE `tbl_pharmacies`
  ADD PRIMARY KEY (`mid`);

--
-- Indexes for table `tbl_prescriptions`
--
ALTER TABLE `tbl_prescriptions`
  ADD PRIMARY KEY (`pr_id`);

--
-- Indexes for table `tbl_requests`
--
ALTER TABLE `tbl_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_requires`
--
ALTER TABLE `tbl_requires`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `tbl_time`
--
ALTER TABLE `tbl_time`
  ADD PRIMARY KEY (`time_id`);

--
-- Indexes for table `tbl_treatments`
--
ALTER TABLE `tbl_treatments`
  ADD PRIMARY KEY (`trt_id`);

--
-- Indexes for table `tbl__amounts`
--
ALTER TABLE `tbl__amounts`
  ADD PRIMARY KEY (`amt_id`);

--
-- Indexes for table `tbl__delievry_addresses`
--
ALTER TABLE `tbl__delievry_addresses`
  ADD PRIMARY KEY (`dl_id`);

--
-- Indexes for table `tbl__doctors`
--
ALTER TABLE `tbl__doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl__orders`
--
ALTER TABLE `tbl__orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `registers`
--
ALTER TABLE `registers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `specilizations`
--
ALTER TABLE `specilizations`
  MODIFY `sid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblcarts`
--
ALTER TABLE `tblcarts`
  MODIFY `cart_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_appoinments`
--
ALTER TABLE `tbl_appoinments`
  MODIFY `a_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_banks`
--
ALTER TABLE `tbl_banks`
  MODIFY `b_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_brands`
--
ALTER TABLE `tbl_brands`
  MODIFY `b_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_cards`
--
ALTER TABLE `tbl_cards`
  MODIFY `c_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  MODIFY `c_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_city`
--
ALTER TABLE `tbl_city`
  MODIFY `city_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_district`
--
ALTER TABLE `tbl_district`
  MODIFY `district_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_doctor_histories`
--
ALTER TABLE `tbl_doctor_histories`
  MODIFY `dh_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_images`
--
ALTER TABLE `tbl_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_leaves`
--
ALTER TABLE `tbl_leaves`
  MODIFY `l_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_medicine_requests`
--
ALTER TABLE `tbl_medicine_requests`
  MODIFY `mr_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_pharmacies`
--
ALTER TABLE `tbl_pharmacies`
  MODIFY `mid` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_prescriptions`
--
ALTER TABLE `tbl_prescriptions`
  MODIFY `pr_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_requests`
--
ALTER TABLE `tbl_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_requires`
--
ALTER TABLE `tbl_requires`
  MODIFY `r_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_time`
--
ALTER TABLE `tbl_time`
  MODIFY `time_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_treatments`
--
ALTER TABLE `tbl_treatments`
  MODIFY `trt_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl__amounts`
--
ALTER TABLE `tbl__amounts`
  MODIFY `amt_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl__delievry_addresses`
--
ALTER TABLE `tbl__delievry_addresses`
  MODIFY `dl_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tbl__doctors`
--
ALTER TABLE `tbl__doctors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl__orders`
--
ALTER TABLE `tbl__orders`
  MODIFY `o_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblcarts`
--
ALTER TABLE `tblcarts`
  ADD CONSTRAINT `tblcarts_id_foreign` FOREIGN KEY (`id`) REFERENCES `registers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tblcarts_mid_foreign` FOREIGN KEY (`mid`) REFERENCES `tbl_pharmacies` (`mid`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_city`
--
ALTER TABLE `tbl_city`
  ADD CONSTRAINT `tbl_city_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `tbl_district` (`district_id`) ON DELETE CASCADE;

--
-- Constraints for table `tbl_images`
--
ALTER TABLE `tbl_images`
  ADD CONSTRAINT `tbl_images_mid_foreign` FOREIGN KEY (`mid`) REFERENCES `tbl_pharmacies` (`mid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
